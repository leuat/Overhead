xmprocdemo
==========

`xmprocdemo` is a very simple demo which embeds a `.xm` file and plays
it back using ALSA. The module is converted to the non-portable
format to save space.

Module used: [Crush by
Drozerix](https://modarchive.org/module.php?179581) (public domain).
